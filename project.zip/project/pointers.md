* Offer a ride. Where I'll be riding and I want people to join me.
* Find a ride. Someone else is driving and they want someone to join to join. Request or get a ride.
* Forgot password is removed in login.html as of now. Can be implemented later.

# Ashwini

* Once logged in user should not see login and register links in home page.